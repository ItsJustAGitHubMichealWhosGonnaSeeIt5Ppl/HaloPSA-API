# HaloPSA API package for Halo
VERY EARLY STAGE, just trying to move this out of my local modules folder right now.  Will improve.
